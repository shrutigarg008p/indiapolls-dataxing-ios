struct DeviceTokenRequestDto: Codable {
    let userId, token: String
}
