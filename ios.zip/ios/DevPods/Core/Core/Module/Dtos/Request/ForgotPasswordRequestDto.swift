struct ForgotPasswordRequestDto: Codable {
    let email: String
}
