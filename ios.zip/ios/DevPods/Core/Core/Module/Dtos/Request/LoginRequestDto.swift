struct LoginRequestDto: Codable {
    let email, password, registerType: String
}
