struct LoginWithOtpRequestDto: Codable {
    let email, phoneNumber, registerType: String
}
