struct ResendOTPRequestDto: Codable {
    let userId: String
    let phoneNumber: String
}
