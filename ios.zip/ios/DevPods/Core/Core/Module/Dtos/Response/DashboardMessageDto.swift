public struct DashboardMessageDto: Codable {
    let messages: String
    let colourCode: String
}
