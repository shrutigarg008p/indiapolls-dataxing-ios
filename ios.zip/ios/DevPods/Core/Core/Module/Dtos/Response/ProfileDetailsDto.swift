public struct ProfileDetailsDto: Codable {
    let profile: ProfileDto?
    let dashboardMessage: DashboardMessageDto?
}
