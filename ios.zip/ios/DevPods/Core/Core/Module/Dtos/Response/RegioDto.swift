struct RegioDto: Codable {
    let cities: [CityDto]
    let state: [StateDto]
}
