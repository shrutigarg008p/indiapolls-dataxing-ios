public struct RegisterResponseDto: Codable {
    let userId, email, phoneNumber: String
}
