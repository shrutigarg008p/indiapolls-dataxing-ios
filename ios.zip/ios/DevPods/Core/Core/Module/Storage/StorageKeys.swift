enum StorageKeys : String, CaseIterable {
    case accessToken
    case auth
    case language
    case isFirstTimeInstall
}
