enum CompletionNavigation {
    case home
    case login
    case back
}
