public struct DashboardMessageUiState {
    public let message: String
    public let color: String
    public let isProfilePending: Bool
}
