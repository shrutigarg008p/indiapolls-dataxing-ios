public enum QuestionDisplayType: Int {
    case dropDown = 1
    case radioButtons = 2
    case checkBoxes = 4
}
