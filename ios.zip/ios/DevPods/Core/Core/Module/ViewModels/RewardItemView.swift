public struct RewardItemView {
    public let name: String
    public let points: Int
}
