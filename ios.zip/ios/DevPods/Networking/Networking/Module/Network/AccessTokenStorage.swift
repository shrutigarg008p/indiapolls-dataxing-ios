public protocol AccessTokenStorage: AnyObject {
    var accessToken: String { get }
}
