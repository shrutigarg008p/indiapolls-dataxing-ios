public protocol LanguageStorage: AnyObject {
    var language: String { get }
}
