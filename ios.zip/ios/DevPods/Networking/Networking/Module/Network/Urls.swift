public struct Urls {
    public static let appUrl = "https://indiapolls.com:9000"
}
