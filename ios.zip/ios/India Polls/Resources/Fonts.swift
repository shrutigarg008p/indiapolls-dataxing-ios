public struct Fonts {
    static let Bold = "Poppins-Bold"
    static let SemiBold = "Poppins-SemiBold"
    static let Medium = "Poppins-Medium"
    static let Regular = "Poppins-Regular"
}
